package com.padcmyanmar.sfc.utils;

/**
 * Created by aung on 12/3/17.
 */

public class AppConstants {

    public static final String ACCESS_TOKEN = "b002c7e1a528b7cb460933fc2875e916";
}

package com.padcmyanmar.sfc.network;

/**
 * Created by aung on 12/9/17.
 */

public abstract class SFCResponse {
}

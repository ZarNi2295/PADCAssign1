package com.padcmyanmar.sfc.activities;

import android.support.v7.app.AppCompatActivity;

/**
 * Created by aung on 12/2/17.
 */

public abstract class BaseActivity extends AppCompatActivity {

}

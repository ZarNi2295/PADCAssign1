# PADC-SFC-News
Walk-through on Android Seven Fundamental Components.
